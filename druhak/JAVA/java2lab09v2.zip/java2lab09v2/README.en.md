# # Java 2 - Exercise 9 v2 SPRING - REST - DESKTOP CLIENT - WEB

<div class="announce" markdown="1">

### Exercise Topics

* Spring - continued
* JPA 1:N entity relationship
* REST API - infinite loop issue during JSON serialization
* Integrating a desktop application with a REST API (Open API Generator)
* Web pages using [Thymeleaf](https://www.thymeleaf.org/)

### Study Materials:

- [Course information and study materials](https://swi.cs.vsb.cz/jezek/student-information/java2.html)
</div>

Use the project <https://gitlab.vsb.cz/jez04-vyuka/java2/labs/java2lab09v2.git>

This is a Maven project with multiple subprojects (Maven modules). It consists of:

- A **Spring Boot** application (website) from the previous exercise
- A **gen-client** project, which is used to generate code based on the REST API description from the OpenAPI specification <http://localhost:8080/v3/api-docs>
- **game**: a standard desktop FX game from  previous exercises

## Already Set Up

#### gen-client

Everything is set up; just run `mvn compile` and the client communication code will be generated.

**The Spring server must be running with the REST API ready**

#### game

The connection to the `gen-client` project is already configured in `pom.xml` and `module-info.java`

## Create

1. Add a `Score` entity to the Spring application, perhaps as a copy of the entity from the game. Establish a 1:N relationship with `Player`
1. Create a simple REST API for both entities
1. Resolve the <https://chatgpt.com/share/69decb22-e4d0-832e-b68c-761dbc96b4a4> looping issue
1. Use the generated client code from `gen-client` to read and save data in the game
    ````java
    PlayerControllerApi api = new PlayerControllerApi();
    api.setCustomBaseUrl("http://localhost:8080");
    List<Player> player = api.getAll();
    ````
1. Create a simple web page with a table of top players using [Thymeleaf](https://www.thymeleaf.org/)

Translated with DeepL.com (free version)