# # Java 2 - 9. cvičení v2 SPRING - REST - DESKTOP CLIENT - WEB

<div class="announce" markdown="1">

### Témata cvičení

* Spring - pokračování
* JPA entity vazba 1:N
* REST API - problém zacyklení při serializaci do JSON 
* Propojení desktop aplikace s REST API (Open API generator)
* Webové stránky s využitím [Thymeleaf](https://www.thymeleaf.org/)

### Studijní materiály:

- [Informace k předmětu a studijní materiály](https://swi.cs.vsb.cz/jezek/student-information/java2.html)
</div>

Použijte projekt <https://gitlab.vsb.cz/jez04-vyuka/java2/labs/java2lab09v2.git>

Jedná se o Maven projekt s více podprojekty (maven moduly). Skládá se ze:

- **spring boot** aplikace (webu) z minulého cvičení
- **gen-client** projektu, který slouží ke kenerování kódu na základě popisu REST API z Open API specifikace <http://localhost:8080/v3/api-docs>
- **hry** standartní desktopová FX hra z  minulých cvičení

## Už nachystáno

#### gen-client
Vše je nastaveno, stačí pustit `mvn compile` a komunikační klientský kód se vygeneruje.

**Musí být spuštěn Spring server s připraveným REST api**

#### hra
Propojení s projektem `gen-client` je již nastaveno v `pom.xml` a v `module-info.java`

## Vytvořte

1. Do spring aplikace přidejte entitu `Score`, třeba jako kopii entity ze hry. Propojte vazbou 1:N s `Player`
1. Vytvořte jednoduché REST api pro obě entity
1. Vyřešte problém se zacyklením <https://chatgpt.com/share/69decb22-e4d0-832e-b68c-761dbc96b4a4>
1. Použijte vygenerovaný klientský kód z `gen-client` k načtení a uložení dat ve hře
    ````java
    PlayerControllerApi api = new PlayerControllerApi();
    api.setCustomBaseUrl("http://localhost:8080");
    List<Player> player = api.getAll();
    ````
1. Vytvořte jednoduchou webovoů stránku s tabulkou nejlepších hráčů s využitím [Thymeleaf](https://www.thymeleaf.org/) 
