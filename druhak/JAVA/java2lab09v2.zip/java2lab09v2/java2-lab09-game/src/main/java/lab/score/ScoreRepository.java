package lab.score;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.SQLException;
import java.util.List;
import java.util.function.Consumer;
import lombok.extern.log4j.Log4j2;
import org.h2.tools.Server;

@Log4j2
public class ScoreRepository {

    private Server server = null;

    private EntityManager em;
    private EntityManagerFactory entityManagerFactory;

    private static ScoreRepository instance;

    public static ScoreRepository getInstance() {
        if (instance == null) {
            instance = new ScoreRepository();
        }
        return instance;
    }

    public ScoreRepository() {
        getEntityManager();

    }

    public void init() {
        startDBWebServer();
        getEntityManager();
    }

    public Score save(Score score) throws ScoreException {
        Score result;
        em.getTransaction().begin();
        if (score.getId() == null || score.getId() == 0) {
            em.persist(score);
            result = score;
        } else {
            result = em.merge(score);
        }
        em.getTransaction().commit();
        return result;
    }

    public void save(List<Score> scores) throws ScoreException {
        for (Score score : scores) {
            save(score);
        }
    }

    public List<Score> load() throws ScoreException {
        return em.createQuery("select s from Score s", Score.class).getResultList();
    }

    public List<Score> loadTopTen() throws ScoreException {
        return em.createQuery("select s from Score s order by s.score desc", Score.class).setMaxResults(10)
            .getResultList();
    }

    public void delete(Score score) throws ScoreException {
        em.getTransaction().begin();
        em.remove(score);
        em.getTransaction().commit();
    }

    public void modifyNoPersistNoMerge(Long id, Consumer<Score> motificator) throws ScoreException {
        em.getTransaction().begin();
        Score score = em.find(Score.class, id);
        motificator.accept(score);
        em.getTransaction().commit();
    }

    public Score find(Long id) throws ScoreException {
        return em.find(Score.class, id);
    }

    public Object getEntityManager() {
        if (entityManagerFactory == null) {
            entityManagerFactory = Persistence.createEntityManagerFactory("java2");
        }
        if (em == null) {
            em = entityManagerFactory.createEntityManager();
        }
        return em;
    }

    private void startDBWebServer() {
        // Start HTTP server for access H2 DB for look inside
        Path h2ServerProperties = Paths.get(System.getProperty("user.home"), ".h2.server.properties");
        try {
            Files.writeString(h2ServerProperties,
                "0=Generic H2 (Embedded)|org.h2.Driver|jdbc\\:h2\\:file\\:./score-db|", StandardOpenOption.CREATE_NEW);
        } catch (IOException e) {
            log.warn("File {} probably exists.", h2ServerProperties);
        }
        stop();
        try {
            server = Server.createWebServer();
            log.info(server.getURL());
            server.start();
            log.info("DB Web server started!");
        } catch (SQLException e) {
            log.error("Cannot create DB web server.", e);
        }
    }

    public void stop() {
        // Stop HTTP server for access H2 DB
        if (server != null) {
            log.info("Ending DB web server BYE.");
            server.stop();
        }
    }

}
