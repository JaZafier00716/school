package cz.vsb.fei.restapi;

//import org.openapitools.client.ApiException;
//import org.openapitools.client.api.PlayerRestControllerApi;

import lombok.extern.log4j.Log4j2;
import org.openapitools.client.ApiException;
import org.openapitools.client.api.PlayerControllerApi;
import org.openapitools.client.api.ScoreControllerApi;
import org.openapitools.client.model.Player;
import org.openapitools.client.model.Score;

import java.time.LocalDate;
import java.util.List;
import java.util.Random;

/**
 *  Class <b>App</b> - main class
 *  @author     Java I
 */
@Log4j2
public class App {

	public static void main(String[] args) {
		log.info("Launching Java application.");
        Random random = new Random();

		//Usage example
		PlayerControllerApi playerApi = new PlayerControllerApi();
		playerApi.setCustomBaseUrl("http://localhost:8080");

        ScoreControllerApi scoreApi = new ScoreControllerApi();
        scoreApi.setCustomBaseUrl("http://localhost:8080");

		try {
			scoreApi.getAll().forEach(log::info);
            playerApi.getAll2().forEach(log::info);

            for(int i = 0; i < 10; i++) {
                Player p = new Player();
                p.setFirstName("Aaa" + i);
                p.setLastName("Bbb" + i);
                p.setDayOfBirth(LocalDate.now());
                playerApi.save2(p);
            }
            List<Player> players = playerApi.getAll2();
            for (int i = 0; i < 10; i++) {
                Score s =  new Score();
                s.setLevel(Score.LevelEnum.MEDIUM);
                s.setScore(random.nextInt(10, 500));
                s.setPlayer(players.get(random.nextInt(players.size())));

                scoreApi.save(s);
            }
		} catch (ApiException e) {
			log.error("Chyba komunikace", e);
		}
	}
	
}