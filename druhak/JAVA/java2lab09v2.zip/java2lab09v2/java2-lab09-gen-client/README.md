# Open API Generator

Tento projekt pouze využívá maven plugin `openapi-generator-maven-plugin`, který spustí
Open API generátor <https://openapi-generator.tech/> a na základě popisu Rest API staženého
z <http://localhost:8080/v3/api-docs> vygeneruje třídy umožňující volat REST API bez nutnosti
práce s HTTP a JSON.
