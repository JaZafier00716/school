package cz.vsb.fei.java.lab09.controllers;
import cz.vsb.fei.java.lab09.entities.Player;
import cz.vsb.fei.java.lab09.entities.Score;
import cz.vsb.fei.java.lab09.repositories.PlayerRepository;
import cz.vsb.fei.java.lab09.repositories.ScoreRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/scores")
public class ScoreController {

    @Autowired
    private ScoreRepository scoreRepository;
    @Autowired
    private PlayerRepository playerRepository;

    @GetMapping({"/", ""})
    public List<Score> getAll(){
        return scoreRepository.findAll();
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> findById(@PathVariable Long id){
        Optional<Score> result = scoreRepository.findById(id);
        if(result.isPresent()){
            return ResponseEntity.ok(result.get());
        } else {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("Player with id " + id + " not found");
        }
    }

    @PostMapping({"/", ""})
    public Score save(@RequestBody Score score){
        Player p = playerRepository.findById(score.getPlayer().getId()).orElse(null);
        score.setPlayer(p);
        return scoreRepository.save(score);
    }
}
