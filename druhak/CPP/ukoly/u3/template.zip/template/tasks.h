#pragma once

class Value {};
